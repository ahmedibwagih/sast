import { Component } from '@angular/core';

@Component({
  templateUrl: 'card.component.html',
  standalone: true,
})
export class CardsComponent {}
