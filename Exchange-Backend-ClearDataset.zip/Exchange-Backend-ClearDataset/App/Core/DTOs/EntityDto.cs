﻿namespace Core.DTOs
{
    public class EntityDto
    {
        public long Id { get; set; }

        //public bool ReadOnly { get; set; }
    }


}
