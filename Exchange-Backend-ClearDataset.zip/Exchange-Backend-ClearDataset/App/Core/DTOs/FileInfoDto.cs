﻿namespace Core.DTOs
{
    public class FileInfoDto
    {
        public string Path { get; set; }

        //public bool ReadOnly { get; set; }
    }


}
