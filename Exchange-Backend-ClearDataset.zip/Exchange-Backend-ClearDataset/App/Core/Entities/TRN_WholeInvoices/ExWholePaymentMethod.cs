﻿using System;
using System.Collections.Generic;

namespace Core.Entities.TRN_WholeInvoices;

public partial class ExWholePaymentMethod
{
    public int PaymentMethod { get; set; }

    public string PaymentMethodNameEn { get; set; }

    public string PaymentMethodNameAr { get; set; }
}
