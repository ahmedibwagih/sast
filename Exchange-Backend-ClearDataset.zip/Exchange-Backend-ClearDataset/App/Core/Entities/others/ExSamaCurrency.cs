﻿using System;
using System.Collections.Generic;

namespace Core.Entities.others;

public partial class ExSamaCurrency
{
    public string Sign { get; set; }

    public int OrderBy { get; set; }
}
