﻿using Core.Entities.LookUps;
using Core.Entities.Sec;
using Core.Repositories.Base;


namespace Core.Repositories.LookUps
{
    public interface ISecFormsFunctionRepository : IRepository<SecFormsFunction>
    {

    }
}
