﻿using Core.Entities.LookUps;

using Core.Repositories.Base;


namespace Core.Repositories.LookUps
{
    public interface IExClientJobRepository : IRepository<ExClientJob>
    {

    }
}
