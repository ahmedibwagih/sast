﻿using Core.Entities.LookUps;
using Core.Repositories.Base;


namespace Core.Repositories.LookUps
{
    public interface ICurrencyRepository : IRepository<Currency>
    {

    }
}
