﻿using Core.Entities.LookUps;
using Core.Entities.TRN_Invoices;
using Core.Repositories.Base;


namespace Core.Repositories.TRN_Invoices
{
    public interface IExInvoicesDetailRepository : IRepository<ExInvoicesDetail>
    {

    }
}
