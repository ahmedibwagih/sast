﻿using Core.Entities.LookUps;
using Core.Entities.TRN_WholeInvoices;
using Core.Repositories.Base;


namespace Core.Repositories.TRN_Transfers
{
    public interface IExWholeInvoicesDetailRepository : IRepository<ExWholeInvoicesDetail>
    {

    }
}
