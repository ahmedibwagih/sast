﻿using System;

namespace Core.Other
{
    public class FilterAttribute:Attribute
    {

    }
}
